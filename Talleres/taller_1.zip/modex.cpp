#include <iostream>

using namespace std;

// Completar
int mod_bin_exp(int x, int y, int n) {
    
}

int main() {
    int c; cin >> c;

    while (c--) {
        int x, y, n; cin >> x >> y >> n;
        cout << mod_bin_exp(x, y, n) << endl;
    }

    return 0;
}
